import torch

def run():
    print("Testing")
    print(torch.cuda.is_available())
    print("Done")
    return

run()
